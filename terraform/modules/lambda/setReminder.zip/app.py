import json
import boto3
import pytz
from datetime import datetime, timedelta
from dateutil import parser

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('reminderTable')


def lambda_handler(event, context):

    try:
        # Parsing the request body
        body = json.loads(event['body'])
        name = body['name']
        contactInfo = body['contactInfo']
        reminderText = body['reminderText']
        reminderTime = body['reminderTime']
        timeZone = body['timeZone']

        # Convert reminder time from the user's timezone to UTC
        userTimeZone = pytz.timezone(timeZone)
        localTime = userTimeZone.localize(parser.parse(reminderTime))
        utc_time = localTime.astimezone(pytz.utc)

        ttl = int(utc_time.timestamp())  # Convert UTC time to Epoch timestamp

        # Generate a numeric reminder ID (as required by your DynamoDB table schema)
        reminderId = int(datetime.now().timestamp())  # Using the current timestamp as the ID

        # Store the reminder in DynamoDB
        response = table.put_item(
            Item={
                'name': name,
                'reminderId': reminderId,
                'contactInfo': contactInfo,
                'reminderText': reminderText,
                'reminderTime': reminderTime,
                'ttl': ttl,
                'timeZone': timeZone
            }
        )

        # Return success response
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Reminder created successfully',
                'reminderId': reminderId
            })
        }
    
    except Exception as e:
        # Return error response in case of failure
        return {
            'statusCode': 500,
            'body': json.dumps({'message': str(e)})
        }
