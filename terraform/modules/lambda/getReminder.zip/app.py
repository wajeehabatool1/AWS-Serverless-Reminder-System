import json
import boto3
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('reminderTable')

def lambda_handler(event, context):
    try:
        # Extract the 'name' query parameter from the event
        userName = event['queryStringParameters']['name']  # Access query parameter directly

        # Query DynamoDB for the reminders associated with the username
        response = table.query(
            KeyConditionExpression="#name = :userName",  # Using a placeholder for the 'name' field
            ExpressionAttributeNames={
                "#name": "name"  # Mapping the placeholder '#name' to the 'name' field in DynamoDB
            },
            ExpressionAttributeValues={
                ":userName": userName  # Use the 'userName' extracted from query parameters
            }
        )

        # Get the list of reminders (Items is the correct key)
        reminders = response.get('Items', [])  # Use 'Items' to get the list of matching records

        # Convert Decimal values to float in the reminders list
        def decimal_to_float(item):
            for key, value in item.items():
                if isinstance(value, Decimal):
                    item[key] = float(value)  # Convert Decimal to float
            return item

        # Apply the conversion to all items in reminders
        reminders = [decimal_to_float(reminder) for reminder in reminders]

        if reminders:
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': f"Found {len(reminders)} reminders for user {userName}",
                    'reminders': reminders
                })
            }
        else:
            return {
                'statusCode': 404,
                'body': json.dumps({
                    'message': f"No reminders found for user {userName}"
                })
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': str(e)
            })
        }
